* Created CSV files training_ib.csv and testing_ib.csv respectively for the training and test dataset provided.
* Imported both train and test csv files into google colab.
*Extracted the class values of train data into y_train.
*Data Visualization:-
  -Plot for visualizing frequency of each class.
  -Word Cloud - used for representing text data in which the size of each word indicates its frequency or importance 

*Data Pre-processing: converted all the test to lower case, removed stopwords and punctuations and applied lemmatization.
*Used TF-IDF , Count vectorizer and applied PCA(principle component analysis) for dimensionality reduction on both.
*Model Building:-
 - ceated a dictionary 'labels' to label all the class values as numbers from 1 to 5.
 -created a function model_performance which would fit the X_train to the model and return the accuracy scores on various types 
of transformed features like tf-idf,count vectorizer,tf-idf with PCA and cv with pca.
 -Follwoing models used :- support vector classifier,random forest classifier, logistic regression, K-nearest neighbours, Naive bayes.
 -plot to visualize different accuracy scores for each model.
*Seeing the accuracy scores, the final model selected is Random Forest classifier.
*Applied hyperparamter optimisation using Grid Search.
*Splitted the training data into train and validation set for fitting into the final model.
*Plotted confusion matrix and calculated Accuarcy, Precision, Recall, F1 and ROC-AUC scores.
*Plotted the roc-auc curve.
*Finally predicted the class values and calculated the confidence scores for the test data set provided.
*Stored the final result in a JSON as well as CSV file.